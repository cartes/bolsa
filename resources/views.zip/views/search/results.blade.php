@extends('layout.app')

@section('content')

    <div class="container-fluid">
        @include('partials.offers.result')
    </div>

@endsection
